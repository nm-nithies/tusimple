# Copyright 2025 Synopsys, Inc.
# This Synopsys software and all associated documentation are proprietary
# to Synopsys, Inc. and may only be used pursuant to the terms and conditions
# of a written license agreement with Synopsys, Inc.
# All other use, reproduction, modification, or distribution of the Synopsys
# software or the associated documentation is strictly prohibited.
from executor import ParallelExecutor, StepExecutor, Step
from executor.executor import bool2result
import os
import sys
from pathlib import Path


_NNSDK_TOP = Path(os.environ["NNSDK_TOP"])


def _run_notebook(notebook):
    return StepExecutor(
        [
            Step(
                cmd=f"jupyter nbconvert --execute --to notebook --inplace {os.path.basename(str(notebook))}".split(),
                cwd=os.path.dirname(str(notebook)),
            ),
            Step(
                cmd=rf"sed -i 's\{_NNSDK_TOP}\<NNSDK_TOP>\g' {str(notebook)}",
                cwd=os.path.dirname(str(notebook)),
                shell=True,
            ),
            Step(
                cmd=rf"sed -i 's\/slowfs/us01dwt2p219/ARCJenkinsTools/ToolsCommon/\<...>/\g' {str(notebook)}",
                cwd=os.path.dirname(str(notebook)),
                shell=True,
            ),
            Step(
                cmd=rf"sed -i 's\/{os.environ['SYNOPSYS_CAFFE_HOME']}\<...>/\g' {str(notebook)}",
                cwd=os.path.dirname(str(notebook)),
                shell=True,
            ),
            Step(
                cmd=r"sed -i '/iopub.execute_input\|iopub.status.busy\|"
                    + rf"iopub.status.idle\|shell.execute_reply/d' {str(notebook)}",
                cwd=os.path.dirname(str(notebook)),
                shell=True,
            ),
        ],
        name=notebook,
    )


tasks = ParallelExecutor(
    processes=16,
    steps=[
        # _run_notebook(
        #     _NNSDK_TOP / "nnac" / "frontend" / "nnac" / "compiler" / "calibration" / "diff_two_pb_histograms.ipynb"
        # ),
        _run_notebook(
            _NNSDK_TOP / "nnac" / "frontend" / "nnac" / "demo" / "custom_op_register" / "example_local_function.ipynb"
        ),
        # _run_notebook(_NNSDK_TOP / "nnac" / "frontend" / "nnac" / "demo" / "train_pruned_model_example.ipynb"),
        _run_notebook(_NNSDK_TOP / "examples" / "public_models" / "LeNet" / "compile_usage.ipynb"),
        _run_notebook(_NNSDK_TOP / "examples" / "public_models" / "LeNet" / "example.ipynb"),
        _run_notebook(_NNSDK_TOP / "examples" / "public_models" / "MobileNetV2_12" / "example.ipynb"),
        # _run_notebook(_NNSDK_TOP / "examples" / "public_models" / "MobileNetV2_CIFAR_QAT" / "MobileNetV2_QAT.ipynb"),
        _run_notebook(_NNSDK_TOP / "examples" / "public_models" / "ResNet50_V1_12" / "example.ipynb"),
        _run_notebook(_NNSDK_TOP / "examples" / "python_api_notebooks" / "convert_usage.ipynb"),
    ],
)

result = tasks.execute()

for step in tasks.steps:
    print(f"Test: {step.name}: {bool2result(step.result)}")

if not result:
    sys.exit(-1)
